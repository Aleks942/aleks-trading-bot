def analyze_symbol(symbol: str, tf: str):
    return {
        "signal": "LONG",
        "strength": "Strong",
        "reasons": [
            "Цена выше MA200",
            "Объём растёт",
            "Положительный тренд"
        ]
    }
